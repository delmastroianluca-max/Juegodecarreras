import {categories} from "../data/categories.js";
import {teams} from "../data/teams.js";
import {Input} from "./input.js";
import {Game} from "./game.js";
import {showScreen,formatTime} from "./ui.js";
import {trackNames,setTrack,track} from "./track.js";

const $=id=>document.getElementById(id);
const teamsFor=categoryId=>teams.filter(t=>t.category===categoryId);
const pointsByPosition=[25,18,15,12,10,8,6,4,2,1];
const championshipCalendar=trackNames.map(t=>t.id);
const careerCalendar=trackNames.map(t=>t.id);
const ownerCalendar=trackNames.map(t=>t.id);
const defaultProfile={races:0,wins:0,podiums:0,championships:0,teamTitles:0,bestLap:null,history:[]};
function readStore(key,fallback){try{return JSON.parse(localStorage.getItem(key))||fallback;}catch{return fallback;}}
function saveStore(key,value){localStorage.setItem(key,JSON.stringify(value));}
let profile={...defaultProfile,...readStore("rs-grand-prix-profile",defaultProfile)};if(!Array.isArray(profile.history))profile.history=[];
let pilotCareer=readStore("rs-pilot-career",null);
let ownerCareer=readStore("rs-owner-career",null);
let selectedCategory=categories[0],selectedTeam=teamsFor("formula")[0],selectedTrack="monaco",selectedCareerCategory=categories[0],selectedCareerTeam=teamsFor("formula")[0],selectedOwnerTeam=teams[0],selectedOwnerCategory="formula";
let currentMode="quick",game=null,currentResult=null,championship=null,careerWasFired=false,ownerLog=[];
const $screen=id=>showScreen(id);
function trackById(id){return trackNames.find(t=>t.id===id)||trackNames[0];}
function modeName(mode){return({quick:"CARRERA RÁPIDA",championship:"CAMPEONATO",timetrial:"CONTRARRELOJ",career:"MODO CARRERA"})[mode]||"GRAND PRIX";}
function renderChoices(){
 const cat=$("category-list"),team=$("team-list"),trackList=$("track-list");if(!cat)return;
 cat.innerHTML="";categories.forEach(c=>{const b=document.createElement("button");b.className="choice"+(c.id===selectedCategory.id?" selected":"");b.innerHTML=`<strong>${c.name}</strong><small>${c.description}</small>`;b.onclick=()=>{selectedCategory=c;selectedTeam=teamsFor(c.id)[0];renderChoices();};cat.append(b);});
 team.innerHTML="";teamsFor(selectedCategory.id).forEach(t=>{const b=document.createElement("button");b.className="team-choice"+(t.id===selectedTeam.id?" selected":"");b.innerHTML=`<span class="team-swatch" style="background:${t.color}"></span><span><b>${t.name}</b><small>${t.drivers.map(d=>`${d.name} #${d.number}`).join(" · ")}</small></span>`;b.onclick=()=>{selectedTeam=t;renderChoices();};team.append(b);});
 trackList.innerHTML="";trackNames.forEach(t=>{const b=document.createElement("button");b.className="track-choice"+(t.id===selectedTrack?" selected":"");b.innerHTML=`<strong>${t.name}</strong><small>${t.difficulty} · ${t.country}</small>`;b.onclick=()=>{selectedTrack=t.id;renderChoices();};trackList.append(b);});
}
function renderCareerChoices(){
 const cats=$("career-category-list"),teamList=$("career-team-list");cats.innerHTML="";categories.forEach(c=>{const b=document.createElement("button");b.className="choice"+(c.id===selectedCareerCategory.id?" selected":"");b.innerHTML=`<strong>${c.name}</strong><small>${c.description}</small>`;b.onclick=()=>{selectedCareerCategory=c;selectedCareerTeam=teamsFor(c.id)[0];renderCareerChoices();};cats.append(b);});
 teamList.innerHTML="";teamsFor(selectedCareerCategory.id).forEach(t=>{const b=document.createElement("button");b.className="team-choice"+(t.id===selectedCareerTeam.id?" selected":"");b.innerHTML=`<span class="team-swatch" style="background:${t.color}"></span><span><b>${t.name}</b><small>${t.drivers.map(d=>`${d.name} #${d.number}`).join(" · ")}</small></span>`;b.onclick=()=>{selectedCareerTeam=t;renderCareerChoices();};teamList.append(b);});
}
function renderTeamInfo(){
 $("all-teams-grid").innerHTML=teams.map(t=>`<article class="team-info-card" style="--team-color:${t.color}"><div class="team-info-title"><span></span><h3>${t.name}</h3></div><p>${t.description}</p><div class="team-meta"><span>NIVEL ${t.rating}/100</span><span>${t.specialty}</span></div><p class="team-budget">PRESUPUESTO ${t.budget}</p><p class="team-drivers"><b>PILOTOS 2026</b><br>${t.drivers.map(d=>`${d.name} #${d.number}`).join(" · ")}</p></article>`).join("");
}
function openSetup(mode){currentMode=mode;$("setup-title").textContent=mode==="championship"?"PREPARÁ EL CAMPEONATO":mode==="timetrial"?"CONTRARRELOJ":"CONFIGURÁ TU CARRERA";$("setup-eyebrow").textContent=modeName(mode)+" · INSCRIPCIÓN";$("setup-description").textContent=mode==="championship"?"Campeonato de 24 fechas para la categoría elegida. Sumá puntos como piloto y como escudería para pelear por los dos títulos.":mode==="timetrial"?"Tres vueltas para conseguir tu mejor registro, sin rivales en pista.":"Elegí categoría, escudería, circuito y distancia.";$("race-laps").value=mode==="timetrial"?"3":"3";if(mode==="championship")championship={round:0,driverPoints:{},teamPoints:{},history:[],schedule:[...championshipCalendar],categoryId:selectedCategory.id,teamId:selectedTeam.id};renderChoices();$screen("setup-screen");}
function toast(message){const el=$("race-toast");if(!el)return;el.textContent=message;el.classList.remove("hidden");window.clearTimeout(toast.timer);toast.timer=window.setTimeout(()=>el.classList.add("hidden"),3600);}
function updateHud(data){$("speed-value").textContent=data.speed;$("time-value").textContent=formatTime(data.time);$("lap-value").innerHTML=`${data.lap} <span>/ ${data.laps}</span>`;$("position-value").innerHTML=`${data.position} <span>/ ${data.total}</span>`;$("damage-value").textContent=`${data.damage}%`;$("damage-value").className=data.damage<25?"damage-good":data.damage<65?"damage-mid":"damage-bad";$("fuel-value").textContent=`${data.fuel}%`;$("tyre-value").textContent=`${data.tyreWear}% · ${data.tyreTemp}°C`;$("engine-value").textContent=`${data.engineTemp}°C / ${data.brakeTemp}°C`;$("tyre-value").className=data.tyreWear<45?"damage-good":data.tyreWear<75?"damage-mid":"damage-bad";$("engine-value").className=data.engineTemp<125&&data.brakeTemp<650?"damage-good":data.engineTemp<135&&data.brakeTemp<780?"damage-mid":"damage-bad";$("speed-value").style.color=data.offroad?"#ef665c":"var(--accent)";}
function startRace(trackId,mode=currentMode){
 if(game)game.stop();currentMode=mode;setTrack(trackId);const laps=mode==="timetrial"?3:(mode==="quick"?Number($("race-laps").value||3):3);const rivals=mode==="timetrial"?0:21;
 const category=mode==="career"?selectedCareerCategory:selectedCategory;const team=mode==="career"?teams.find(t=>t.id===pilotCareer.teamId&&t.category===selectedCareerCategory.id)||selectedCareerTeam:selectedTeam;
 const driverName=mode==="career"?pilotCareer.driverName:(team.drivers?.[0]?.name||"PILOTO RS");
 $("race-title").textContent=category.name;$("race-mode-label").textContent=`${modeName(mode)} · ${track.name.toUpperCase()}`;$("track-note").innerHTML=`${track.name.toUpperCase()} <span>·</span> ${track.difficulty} <span>·</span> ${rivals+1} ${rivals===0?"PILOTO":"AUTOS"}`;
 $("pause-overlay").classList.add("hidden");$("race-toast").classList.add("hidden");$screen("race-screen");
 const input=new Input();game=new Game($("game-canvas"),input,category,team,updateHud,{laps,rivalCount:rivals,driverName,onFinish:handleRaceFinish});game.render();game.start();
}
function addProfileResult(result){profile.races++;if(result.position===1)profile.wins++;if(result.position<=3)profile.podiums++;if(result.bestLap!==null&&result.bestLap!==undefined)profile.bestLap=profile.bestLap===null?result.bestLap:Math.min(profile.bestLap,result.bestLap);profile.history.unshift({date:new Date().toLocaleDateString("es-AR"),track:result.trackName,position:result.position,time:result.time,mode:currentMode});profile.history=profile.history.slice(0,30);saveStore("rs-grand-prix-profile",profile);}
function updateChampionship(result){
 result.entries.forEach(e=>{
  const pts=pointsByPosition[e.position-1]||0;
  championship.driverPoints[e.name]=(championship.driverPoints[e.name]||0)+pts;
  championship.teamPoints[e.team]=(championship.teamPoints[e.team]||0)+pts;
 });
 championship.history.push({track:result.trackName,position:result.position,points:pointsByPosition[result.position-1]||0});
 championship.round++;
}
function championshipRows(points){
 return Object.entries(points).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])).map(([name,pts],i)=>`<div class="standing-row"><b>${i+1}.</b><span></span><span>${name}</span><strong>${pts} PTS</strong></div>`).join("")||'<p class="muted-copy">Todavía no hay puntos.</p>';
}
function renderChampionshipStandings(){
 const panel=$("championship-standings");
 if(currentMode!=="championship"||!championship){panel.classList.add("hidden");return;}
 panel.classList.remove("hidden");
 $("driver-standings").innerHTML=championshipRows(championship.driverPoints);
 $("team-standings").innerHTML=championshipRows(championship.teamPoints);
}
function updatePilotCareer(result){
 const pts=pointsByPosition[result.position-1]||0;pilotCareer.races++;pilotCareer.seasonPoints+=pts;pilotCareer.totalPoints+=pts;pilotCareer.wins+=result.position===1?1:0;pilotCareer.podiums+=result.position<=3?1:0;pilotCareer.history.unshift({season:pilotCareer.season,round:pilotCareer.eventIndex+1,track:result.trackName,position:result.position,points:pts});pilotCareer.recentFinishes.push(result.position);pilotCareer.recentFinishes=pilotCareer.recentFinishes.slice(-4);pilotCareer.eventIndex++;
 let message=`Sumaste ${pts} puntos. Llevás ${pilotCareer.seasonPoints} en la temporada.`;
 if(pilotCareer.recentFinishes.length===4&&pilotCareer.recentFinishes.filter(n=>n>=8).length>=3){pilotCareer.fired=true;message="La escudería perdió la confianza: tres resultados muy malos en las últimas cuatro carreras. Te despidieron.";}
 if(pilotCareer.eventIndex>=careerCalendar.length&&!pilotCareer.fired){
  if(pilotCareer.seasonPoints>=110){profile.championships++;const current=teams.find(t=>t.id===pilotCareer.teamId);const offer=teams.filter(t=>t.category===pilotCareer.categoryId&&t.rating>(current?.rating||0)).sort((a,b)=>a.rating-b.rating)[0];if(offer){pilotCareer.teamId=offer.id;message=`¡CAMPEÓN DE TEMPORADA! ${offer.name} te ofrece un contrato para la próxima temporada.`;}else message="¡CAMPEÓN DE TEMPORADA! Defendés tu título con la misma escudería.";}
  else if(pilotCareer.seasonPoints<35){pilotCareer.fired=true;message="La temporada fue muy complicada y la escudería decidió despedirte.";}
  else message="Temporada completada. Tu equipo renueva el contrato por un año más.";
  if(!pilotCareer.fired){pilotCareer.season++;pilotCareer.eventIndex=0;pilotCareer.seasonPoints=0;pilotCareer.recentFinishes=[];}
 }
 saveStore("rs-pilot-career",pilotCareer);saveStore("rs-grand-prix-profile",profile);return message;
}
function handleRaceFinish(result){
 currentResult=result;addProfileResult(result);
 let message="Carrera finalizada. Revisá la clasificación oficial.";
 if(currentMode==="championship"){updateChampionship(result);message=`Sumaste ${pointsByPosition[result.position-1]||0} puntos para el campeonato. Fecha ${championship.round} de ${championship.schedule.length}.`;}
 if(currentMode==="career")message=updatePilotCareer(result);
 if(currentMode==="timetrial")message=`Mejor vuelta: ${result.bestLap?formatTime(result.bestLap):"sin registro"}. Tu tiempo queda guardado en el palmarés.`;
 showResults(result,message);
}
function showResults(result,message){
 const isTimeTrial=currentMode==="timetrial";const podium=result.entries.slice(0,3);const playerPodium=result.position<=3;
 $("championship-standings").classList.add("hidden");
 $("result-eyebrow").textContent=isTimeTrial?"CONTRARRELOJ · RESULTADO":playerPodium?"PODIO · RESULTADO OFICIAL":"CLASIFICACIÓN OFICIAL";
 $("result-title").textContent=isTimeTrial?"VUELTA COMPLETADA":result.position===1?"¡GANASTE EL GRAN PREMIO!":playerPodium?"¡ESTÁS EN EL PODIO!":"RESULTADO FINAL";
 $("result-subtitle").textContent=`${result.trackName} · ${result.position}.º de ${result.entries.length} · Tiempo ${formatTime(result.time)}`;
 $("podium-wrap").innerHTML=podium.map((e,i)=>`<article class="podium-card ${i===0?"first":i===1?"second":"third"}" style="--medal:${["#e7c35b","#b9c7d0","#c98a52"][i]};--team-color:${e.color}"><div class="podium-medal">${["1.º","2.º","3.º"][i]}</div><div class="podium-name">${e.isPlayer?"TÚ · ":""}${e.name}</div><div class="podium-team-color"></div><div class="podium-team">${e.team}</div><div class="podium-base"></div></article>`).join("");
 $("results-table-body").innerHTML=result.entries.map(e=>`<tr class="${e.isPlayer?"player-row":""}"><td>${e.position}.º</td><td>${e.isPlayer?"★ ":""}${e.name}</td><td><span class="table-team-dot" style="background:${e.color}"></span>${e.team}</td><td>${e.isPlayer?formatTime(result.time):e.finished?formatTime(e.time):"En pista"}</td><td>${currentMode==="championship"||currentMode==="career"?pointsByPosition[e.position-1]||0:"—"}</td></tr>`).join("");
 $("result-message").textContent=message;
 const next=$("next-event-button");next.classList.remove("hidden");next.textContent=currentMode==="quick"?"OTRA CARRERA →":currentMode==="career"?"SIGUIENTE GRAN PREMIO →":currentMode==="championship"?"SIGUIENTE FECHA →":"OTRA SESIÓN →";
 if(currentMode==="championship"&&championship.round>=championship.schedule.length){
  next.classList.add("hidden");
  const drivers=Object.entries(championship.driverPoints).sort((a,b)=>b[1]-a[1]);
  const teamsTable=Object.entries(championship.teamPoints).sort((a,b)=>b[1]-a[1]);
  const driverChampion=drivers[0],teamChampion=teamsTable[0];
  $("result-message").textContent+=`\nTEMPORADA COMPLETADA · ${categories.find(c=>c.id===championship.categoryId)?.name||"CAMPEONATO"}\n`+(driverChampion?`CAMPEÓN DE PILOTOS: ${driverChampion[0]} (${driverChampion[1]} pts).\n`:"")+(teamChampion?`CAMPEÓN DE ESCUDERÍAS: ${teamChampion[0]} (${teamChampion[1]} pts).`:"");
  if(teamChampion&&teamChampion[0]===selectedTeam.name){profile.teamTitles=(profile.teamTitles||0)+1;}
  if(driverChampion&&driverChampion[0]===(selectedTeam.drivers?.[0]?.name||"")){profile.championships=(profile.championships||0)+1;}
  saveStore("rs-grand-prix-profile",profile);
 }
 renderChampionshipStandings();
 if(currentMode==="career"&&pilotCareer.fired){next.textContent="BUSCAR NUEVA ESCUDERÍA →";}
 if(currentMode==="career"&&!pilotCareer.fired&&pilotCareer.eventIndex===0){next.textContent="INICIAR NUEVA TEMPORADA →";}
 if(currentMode==="timetrial"){next.textContent="OTRA SESIÓN →";}
 renderChampionshipStandings();
 $screen("results-screen");
}
function nextEvent(){
 if(game)game.stop();
 if(currentMode==="championship"){if(championship.round>=championship.schedule.length){$screen("menu-screen");return;}startRace(championship.schedule[championship.round],"championship");return;}
 if(currentMode==="career"){
  if(pilotCareer.fired){careerWasFired=true;selectedCareerCategory=categories.find(c=>c.id===pilotCareer.categoryId)||categories[0];selectedCareerTeam=teams.find(t=>t.id===pilotCareer.teamId&&t.category===selectedCareerCategory.id)||teamsFor(selectedCareerCategory.id)[0];renderCareerChoices();$screen("career-pilot-screen");return;}
  startRace(careerCalendar[pilotCareer.eventIndex],"career");return;
 }
 if(currentMode==="timetrial"){openSetup("timetrial");return;}openSetup("quick");
}
function startPilotCareer(){
 const name=($("driver-name").value.trim().replace(/[<>]/g,"").slice(0,22))||"TU PILOTO RS";
 if(careerWasFired&&pilotCareer){pilotCareer.teamId=selectedCareerTeam.id;pilotCareer.categoryId=selectedCareerCategory.id;pilotCareer.driverName=name;pilotCareer.fired=false;pilotCareer.eventIndex=0;pilotCareer.seasonPoints=0;pilotCareer.recentFinishes=[];pilotCareer.season++;}
 else pilotCareer={active:true,driverName:name,teamId:selectedCareerTeam.id,categoryId:selectedCareerCategory.id,season:1,eventIndex:0,seasonPoints:0,totalPoints:0,races:0,wins:0,podiums:0,recentFinishes:[],history:[],fired:false};
 careerWasFired=false;saveStore("rs-pilot-career",pilotCareer);currentMode="career";selectedCareerCategory=categories.find(c=>c.id===pilotCareer.categoryId)||selectedCareerCategory;startRace(careerCalendar[pilotCareer.eventIndex],"career");
}
function renderProfile(){
 const c=pilotCareer;const best=profile.bestLap===null?"—":formatTime(profile.bestLap);
 $("profile-content").innerHTML=`<article class="profile-stat"><small>CARRERAS COMPLETADAS</small><strong>${profile.races}</strong></article><article class="profile-stat"><small>VICTORIAS</small><strong>${profile.wins}</strong></article><article class="profile-stat"><small>PODIOS</small><strong>${profile.podiums}</strong></article><article class="profile-stat"><small>TÍTULOS DE PILOTO</small><strong>${profile.championships}</strong></article><article class="profile-stat"><small>TÍTULOS DE ESCUDERÍA</small><strong>${profile.teamTitles||0}</strong></article><article class="profile-stat"><small>MEJOR VUELTA</small><strong>${best}</strong></article><article class="profile-stat"><small>PUNTOS DE CARRERA</small><strong>${c?.totalPoints||0}</strong></article><article class="profile-summary panel"><h3>TRAYECTORIA DE PILOTO</h3>${c?`<p><b>${c.driverName}</b> · ${teams.find(t=>t.id===c.teamId)?.name||"Sin escudería"}. Temporada ${c.season}, ${c.seasonPoints} puntos actuales. ${c.fired?"Actualmente sin contrato.":"Contrato activo."}</p>`:"<p>Todavía no empezaste un modo carrera como piloto. Tus resultados de carreras rápidas quedan registrados arriba.</p>"}<h3>ÚLTIMOS RESULTADOS</h3>${profile.history.length?profile.history.slice(0,8).map(h=>`<div class="owner-log-entry">${h.date} · ${h.track} · ${h.position}.º · ${formatTime(h.time)}</div>`).join("") :"<p class='muted-copy'>Todavía no hay resultados guardados.</p>"}</article>`;
}
function renderOwnerTeamChoices(){const el=$("owner-team-list");el.innerHTML="";const driverSelect=$("owner-driver-select");driverSelect.innerHTML=selectedOwnerTeam.drivers.map(d=>`<option value="${d.name}">${d.name} #${d.number}</option>`).join("");const categoryTabs=document.getElementById("owner-category-tabs");if(categoryTabs){categoryTabs.innerHTML=categories.map(c=>`<button class="secondary-button ${c.id===selectedOwnerCategory?"selected":""}" data-owner-category="${c.id}">${c.name}</button>`).join("");categoryTabs.querySelectorAll("[data-owner-category]").forEach(b=>b.onclick=()=>{selectedOwnerCategory=b.dataset.ownerCategory;selectedOwnerTeam=teamsFor(selectedOwnerCategory)[0];renderOwnerTeamChoices();});}teamsFor(selectedOwnerCategory).forEach(t=>{const b=document.createElement("button");b.className="team-choice"+(t.id===selectedOwnerTeam.id?" selected":"");b.innerHTML=`<span class="team-swatch" style="background:${t.color}"></span><span><b>${t.name} · NIVEL ${t.rating}</b><small>${t.drivers.map(d=>`${d.name} #${d.number}`).join(" · ")}</small></span>`;b.onclick=()=>{selectedOwnerTeam=t;renderOwnerTeamChoices();};el.append(b);});}
function freshOwnerStandings(categoryId=selectedOwnerCategory){return Object.fromEntries(teamsFor(categoryId).map(t=>[t.id,0]));}
function startOwnerCareer(){ownerCareer={teamId:selectedOwnerTeam.id,driver:$("owner-driver-select").value,season:1,eventIndex:0,budget:42000000,engine:1,aero:1,chassis:1,suspension:1,brakes:1,cooling:1,reliability:1,strategy:1,pitcrew:1,factory:1,windTunnel:1,simulator:1,design:1,staff:{chief:0,aero:0,engineer:0,mechanic:0,strategy:0},driverStats:{pace:78,experience:55,morale:75,contract:2,salary:1200000},sponsors:2,points:0,wins:0,podiums:0,titles:0,history:[],standings:Object.fromEntries(teamsFor(selectedOwnerTeam.category).map(t=>[t.id,0])),category:selectedOwnerTeam.category,staff:{chief:0,aero:0,engineer:0,mechanic:0,strategy:0}};saveStore("rs-owner-career",ownerCareer);$("owner-team-select").classList.add("hidden");$("owner-management").classList.remove("hidden");renderOwner();}
const ownerDepartments=[['engine','Unidad de potencia','Potencia y eficiencia energética',2200000],['aero','Aerodinámica','Carga, eficiencia y DRS',1800000],['chassis','Chasis','Peso, rigidez y equilibrio',1500000],['suspension','Suspensión','Tracción y paso por curva',1100000],['brakes','Frenos','Frenada y temperatura',850000],['cooling','Refrigeración','Control térmico y fiabilidad',900000],['reliability','Fiabilidad','Menos averías y abandonos',1300000],['strategy','Departamento de estrategia','Modelos de carrera y decisiones',1000000],['pitcrew','Equipo de boxes','Velocidad y consistencia en paradas',950000],['factory','Fábrica','Capacidad de producción',2400000],['windTunnel','Túnel de viento','Correlación aerodinámica',1900000],['simulator','Simulador','Preparación de pilotos',1200000],['design','Centro de diseño','Velocidad de desarrollo',1600000]];
function renderOwner(){
 if(!ownerCareer)return;if(!ownerCareer.standings)ownerCareer.standings=Object.fromEntries(teamsFor(ownerCareer.category||"formula").map(t=>[t.id,0]));
 ownerDepartments.forEach(([key])=>{if(ownerCareer[key]===undefined)ownerCareer[key]=key==='engine'||key==='aero'?ownerCareer[key]||0:1;});
 const team=teams.find(t=>t.id===ownerCareer.teamId)||teams[0];ownerCareer.category=ownerCareer.category||team.category;ownerCareer.staff=ownerCareer.staff||{chief:0,aero:0,engineer:0,mechanic:0,strategy:0};ownerCareer.driverStats=ownerCareer.driverStats||{pace:78,experience:55,morale:75,contract:2,salary:1200000};$("owner-team-title").textContent=team.name;$("owner-season-label").textContent=`Temporada ${ownerCareer.season} · Fecha ${ownerCareer.eventIndex+1} de ${ownerCalendar.length} · Piloto: ${ownerCareer.driver}`;
 const rating=Math.min(99,team.rating+['engine','aero','chassis','suspension','brakes','cooling','reliability'].reduce((n,k)=>n+Math.max(0,ownerCareer[k]-1)*.7,0));
 $("owner-dashboard").innerHTML=`<article class="owner-stat"><small>PRESUPUESTO DISPONIBLE</small><strong>$${ownerCareer.budget.toLocaleString("es-AR")}</strong></article><article class="owner-stat"><small>VALORACIÓN DEL EQUIPO</small><strong>${Math.round(rating)}/100</strong></article><article class="owner-stat"><small>PUNTOS DE TEMPORADA</small><strong>${ownerCareer.points}</strong></article><article class="owner-stat"><small>VICTORIAS / PODIOS</small><strong>${ownerCareer.wins} / ${ownerCareer.podiums}</strong></article><article class="owner-stat"><small>PILOTO · RITMO</small><strong>${ownerCareer.driverStats.pace}/100</strong></article><article class="owner-stat"><small>MORAL DEL PILOTO</small><strong>${ownerCareer.driverStats.morale}/100</strong></article><article class="owner-stat"><small>PRÓXIMO GP</small><strong style="font-size:17px">${trackById(ownerCalendar[ownerCareer.eventIndex%ownerCalendar.length]).name}</strong></article><article class="owner-stat"><small>TÍTULOS DE EQUIPO</small><strong>${ownerCareer.titles}</strong></article>`;
 $("owner-departments").innerHTML=ownerDepartments.map(([key,label,desc,cost])=>`<article class="department-card"><div><b>${label}</b><small>${desc}</small></div><strong>NIVEL ${ownerCareer[key]}</strong><button data-upgrade="${key}" ${ownerCareer[key]>=10||ownerCareer.budget<cost?'disabled':''}>MEJORAR · $${cost.toLocaleString('es-AR')}</button></article>`).join('');
 const staffLabels={chief:'Director deportivo',aero:'Ingeniero aerodinámico',engineer:'Ingeniero de carrera',mechanic:'Mecánicos',strategy:'Estrategas'};
 $("owner-staff").innerHTML=`<h3>PERSONAL Y CONTRATACIONES</h3><div class="staff-grid">${Object.entries(staffLabels).map(([key,label])=>`<article><b>${label}</b><small>Plantilla: ${ownerCareer.staff[key]}</small><button data-hire="${key}" ${ownerCareer.budget<650000?'disabled':''}>CONTRATAR · $650.000</button></article>`).join('')}</div><div class="driver-contract"><b>${ownerCareer.driver}</b><span>Experiencia ${ownerCareer.driverStats.experience}/100 · Contrato ${ownerCareer.driverStats.contract} años · Salario $${ownerCareer.driverStats.salary.toLocaleString('es-AR')}/año</span><button id="renew-driver">RENOVAR CONTRATO · $900.000</button></div>`;
 $("owner-finance").innerHTML=`<h3>FINANZAS Y PATROCINADORES</h3><p>Patrocinadores activos: <b>${ownerCareer.sponsors}</b> · Ingreso estimado por GP: <b>$${(ownerCareer.sponsors*420000).toLocaleString('es-AR')}</b> · Nómina anual: <b>$${(Object.values(ownerCareer.staff).reduce((a,b)=>a+b,0)*320000+ownerCareer.driverStats.salary).toLocaleString('es-AR')}</b></p><button id="owner-sponsor" ${ownerCareer.budget<300000?'disabled':''}>FIRMAR PATROCINADOR · $300.000 de activación</button>`;
 const ordered=teamsFor("formula").map(t=>({team:t,points:ownerCareer.standings[t.id]||0})).sort((a,b)=>b.points-a.points);$("owner-standings").innerHTML=ordered.map((entry,i)=>`<div class="standing-row ${entry.team.id===team.id?"your-team":""}"><b>${i+1}</b><span class="team-swatch" style="background:${entry.team.color}"></span><span>${entry.team.name}</span><strong>${entry.points} pts</strong></div>`).join("");
 $("owner-log").innerHTML=ownerCareer.history.length?ownerCareer.history.slice(0,12).map(h=>`<div class="owner-log-entry">Temporada ${h.season} · ${h.track} · ${h.position}.º · ${h.points} pts · ${h.driver}</div>`).join(""):`<p class="muted-copy">Tu escudería todavía no disputó ningún gran premio. Mejorá el auto y prepará el debut.</p>`;
 $("upgrade-engine").disabled=ownerCareer.engine>=10||ownerCareer.budget<2200000;$("upgrade-aero").disabled=ownerCareer.aero>=10||ownerCareer.budget<1800000;
}
function upgradeDepartment(key){const item=ownerDepartments.find(d=>d[0]===key);if(!item||!ownerCareer)return;const cost=item[3];if(ownerCareer[key]>=10||ownerCareer.budget<cost)return;ownerCareer.budget-=cost;ownerCareer[key]++;saveStore('rs-owner-career',ownerCareer);renderOwner();}
function hireStaff(key){if(!ownerCareer||ownerCareer.budget<650000)return;ownerCareer.budget-=650000;ownerCareer.staff[key]=(ownerCareer.staff[key]||0)+1;saveStore('rs-owner-career',ownerCareer);renderOwner();}

function upgradeOwner(type){upgradeDepartment(type);}
function simulateOwnerRace(){
 if(!ownerCareer)return;const team=teams.find(t=>t.id===ownerCareer.teamId)||teams[0],ownerTeams=teamsFor(ownerCareer.category||team.category),eventTrack=trackById(ownerCalendar[ownerCareer.eventIndex%ownerCalendar.length]);if(!ownerCareer.standings)ownerCareer.standings=Object.fromEntries(teamsFor(ownerCareer.category||"formula").map(t=>[t.id,0]));const competitors=ownerTeams.map(t=>({team:t,score:t.rating+(t.id===team.id?(ownerCareer.engine+ownerCareer.aero+ownerCareer.chassis+ownerCareer.suspension+ownerCareer.brakes+ownerCareer.cooling+ownerCareer.reliability-7)*1.15+ownerCareer.strategy*.8+ownerCareer.pitcrew*.5+ownerCareer.driverStats.pace*.08:0)+(Math.random()*18-9)})).sort((a,b)=>b.score-a.score);competitors.forEach((c,i)=>ownerCareer.standings[c.team.id]=(ownerCareer.standings[c.team.id]||0)+(pointsByPosition[i]||0));const position=competitors.findIndex(c=>c.team.id===team.id)+1,pts=pointsByPosition[position-1]||0;ownerCareer.points=ownerCareer.standings[team.id];ownerCareer.wins+=position===1?1:0;ownerCareer.podiums+=position<=3?1:0;const prize=position===1?1600000:position<=3?900000:position<=6?450000:180000;ownerCareer.budget+=prize+ownerCareer.sponsors*420000;ownerCareer.driverStats.experience=Math.min(100,ownerCareer.driverStats.experience+1);ownerCareer.driverStats.morale=Math.min(100,Math.max(35,ownerCareer.driverStats.morale+(position<=3?4:-3)));ownerCareer.history.unshift({season:ownerCareer.season,track:eventTrack.name,position,points:pts,driver:ownerCareer.driver});ownerCareer.eventIndex++;
 let msg=`${eventTrack.name}: ${team.name} terminó ${position}.º. ${ownerCareer.driver} sumó ${pts} puntos. Premio: $${prize.toLocaleString("es-AR")}.`;
 if(ownerCareer.eventIndex>=ownerCalendar.length){ownerCareer.lastSeasonPoints=ownerCareer.points;const champion=ownerTeams.map(t=>({team:t,points:ownerCareer.standings[t.id]||0})).sort((a,b)=>b.points-a.points)[0];if(champion?.team.id===team.id){ownerCareer.titles++;profile.teamTitles=(profile.teamTitles||0)+1;saveStore("rs-grand-prix-profile",profile);msg+=` ¡Tu escudería ganó el campeonato de equipos con ${champion.points} puntos!`;}else msg+=` Temporada finalizada. El título fue para ${champion?.team.name||"otro equipo"}.`;ownerCareer.season++;ownerCareer.eventIndex=0;ownerCareer.points=0;ownerCareer.standings=freshOwnerStandings(ownerCareer.category||"formula");ownerCareer.engine=Math.min(10,ownerCareer.engine);ownerCareer.aero=Math.min(10,ownerCareer.aero);}
 saveStore("rs-owner-career",ownerCareer);renderOwner();$("owner-log").scrollIntoView({behavior:"smooth",block:"nearest"});toastOwner(msg);
}
function toastOwner(msg){const log=$("owner-log");const el=document.createElement("div");el.className="owner-log-entry owner-latest";el.textContent="ÚLTIMO GP · "+msg;log.prepend(el);}

// Main navigation and setup.
document.querySelectorAll(".mode-btn").forEach(b=>b.addEventListener("click",()=>openSetup(b.dataset.mode)));
$("career-button").onclick=()=>{$("continue-pilot").classList.toggle("hidden",!pilotCareer?.active);$("continue-owner").classList.toggle("hidden",!ownerCareer);$("career-resume-actions").classList.toggle("hidden",!(pilotCareer?.active||ownerCareer));$screen("career-role-screen");};
$("setup-back").onclick=()=>{$screen("menu-screen");};
$("start-race-button").onclick=()=>{if(currentMode==="championship")championship={round:0,points:{},history:[],schedule:[selectedTrack,...championshipCalendar.filter(id=>id!==selectedTrack)]};startRace(selectedTrack,currentMode);};
$("exit-race-button").onclick=()=>{if(game)game.stop();$screen(currentMode==="career"?"career-role-screen":"menu-screen");};
$("resume-button").onclick=()=>{$("pause-overlay").classList.add("hidden");if(game)game.setPaused(false);};
$("results-menu").onclick=()=>{$screen("menu-screen");};$("next-event-button").onclick=nextEvent;
$("teams-button").onclick=()=>{renderTeamInfo();$screen("teams-screen");};$("teams-back").onclick=()=>{$screen("menu-screen");};
$("profile-button").onclick=()=>{renderProfile();$screen("profile-screen");};$("profile-back").onclick=()=>{$screen("menu-screen");};
$("career-role-back").onclick=()=>{$screen("menu-screen");};
$("choose-pilot").onclick=()=>{careerWasFired=false;renderCareerChoices();if(pilotCareer?.fired){careerWasFired=true;selectedCareerCategory=categories.find(c=>c.id===pilotCareer.categoryId)||categories[0];selectedCareerTeam=teams.find(t=>t.id===pilotCareer.teamId&&t.category===selectedCareerCategory.id)||teamsFor(selectedCareerCategory.id)[0];renderCareerChoices();$("driver-name").value=pilotCareer.driverName||"TU PILOTO RS";}else{$("driver-name").value="TU PILOTO RS";} $screen("career-pilot-screen");};
$("choose-owner").onclick=()=>{renderOwnerTeamChoices();$("owner-team-select").classList.remove("hidden");$("owner-management").classList.add("hidden");$screen("owner-screen");};
$("continue-pilot").onclick=()=>{if(!pilotCareer)return;careerWasFired=!!pilotCareer.fired;selectedCareerCategory=categories.find(c=>c.id===pilotCareer.categoryId)||categories[0];selectedCareerTeam=teams.find(t=>t.id===pilotCareer.teamId&&t.category===selectedCareerCategory.id)||teamsFor(selectedCareerCategory.id)[0];if(pilotCareer.fired){renderCareerChoices();$("driver-name").value=pilotCareer.driverName;$screen("career-pilot-screen");}else{currentMode="career";startRace(careerCalendar[pilotCareer.eventIndex],"career");}};
$("continue-owner").onclick=()=>{if(!ownerCareer)return;$("owner-team-select").classList.add("hidden");$("owner-management").classList.remove("hidden");renderOwner();$screen("owner-screen");};
$("pilot-back").onclick=()=>{$screen("career-role-screen");};$("start-pilot-career").onclick=startPilotCareer;
$("owner-menu").onclick=()=>{$screen("menu-screen");};$("start-owner-career").onclick=startOwnerCareer;$("upgrade-engine").onclick=()=>upgradeOwner("engine");$("upgrade-aero").onclick=()=>upgradeOwner("aero");$("owner-next-race").onclick=simulateOwnerRace;
$("owner-departments").addEventListener("click",e=>{const b=e.target.closest("[data-upgrade]");if(b)upgradeDepartment(b.dataset.upgrade);});
$("owner-staff").addEventListener("click",e=>{const b=e.target.closest("[data-hire]");if(b)hireStaff(b.dataset.hire);if(e.target.id==="renew-driver"&&ownerCareer?.budget>=900000){ownerCareer.budget-=900000;ownerCareer.driverStats.contract+=2;ownerCareer.driverStats.morale=Math.min(100,ownerCareer.driverStats.morale+8);saveStore("rs-owner-career",ownerCareer);renderOwner();}});
$("owner-finance").addEventListener("click",e=>{if(e.target.id==="owner-sponsor"&&ownerCareer?.budget>=300000){ownerCareer.budget-=300000;ownerCareer.sponsors++;saveStore("rs-owner-career",ownerCareer);renderOwner();}});
window.addEventListener("keydown",e=>{
 if(e.key==="Escape"&&game&&!$("race-screen").classList.contains("hidden")){const overlay=$("pause-overlay"),paused=overlay.classList.toggle("hidden")===false;game.setPaused(paused);}
});
renderChoices();renderCareerChoices();
if(ownerCareer){$("owner-team-select").classList.add("hidden");$("owner-management").classList.remove("hidden");renderOwner();}
if(pilotCareer?.driverName&&$("driver-name"))$("driver-name").value=pilotCareer.driverName;
