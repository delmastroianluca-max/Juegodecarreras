RACING SIMULATOR 2D — GRAND PRIX / TOP-DOWN EDITION 1.7

PROYECTO
Simulador de carreras 2D con vista superior real, cámara de seguimiento y circuitos amplios dibujados en Canvas.
Incluye cuatro categorías, 24 circuitos, 44 escuderías y 88 pilotos de la parrilla oficial de F1 2026.
Carrera rápida, campeonato de 24 fechas, contrarreloj y modos de carrera como piloto y dueño de equipo.

CÓMO EJECUTAR EN CACHYOS / LINUX
1. Extraer el ZIP.
2. Abrir Ptyxis.
3. Entrar a la carpeta que contiene index.html:
   cd ~/Descargas/racingsimulator2d/RacingSimulator2D_GrandPrix_TopDown_GestionF1/RacingSimulator2D_GrandPrix_Isometrico
4. Ejecutar:
   python -m http.server 8000
5. Abrir Firefox en:
   http://localhost:8000

CONTROLES EN CARRERA
W o flecha arriba: acelerar
S o flecha abajo: frenar
A / D o flechas izquierda / derecha: girar
Espacio: freno de mano
Escape: pausa

MODOS DE JUEGO
- Carrera rápida: elegir categoría, escudería, circuito y número de vueltas.
- Campeonato: 24 grandes premios, puntos por posición y tabla de equipos.
- Contrarreloj: tres vueltas sin rivales; registra la mejor vuelta.
- Modo carrera / Piloto: temporada de 24 grandes premios, contratos, puntos,
  posibles ascensos a equipos más fuertes y despido por resultados muy malos.
- Modo carrera / Dueño: elegir equipo y uno de sus pilotos, administrar presupuesto,
  desarrollar motor, aerodinámica, chasis, suspensión, frenos, refrigeración,
  fiabilidad, estrategia, boxes e instalaciones; contratar personal y gestionar
  contratos, moral, salarios, patrocinadores, ingresos y gastos.

CIRCUITOS
Los 24 trazados del calendario se mantienen seleccionables. Esta etapa mejora la escala visual de la calzada, las escapatorias y la ambientación de boxes/pit lane. Los puntos centrales heredados siguen siendo aproximaciones 2D y todavía no equivalen a levantamientos fieles de cada trazado real.

Monaco, Spa-Francorchamps, Silverstone, Suzuka, Baréin, Singapur, Interlagos,
Circuit of The Americas, Gilles-Villeneuve, Portimão, Zandvoort, Monza, Imola,
Barcelona-Catalunya, Hungaroring, Red Bull Ring, Yas Marina, Jeddah, Bakú,
Shanghai, Albert Park, Lusail, Ciudad de México y Las Vegas.

CAMBIOS DE ESTA VERSIÓN
- Pistas ensanchadas a 232 unidades de ancho, con escapatorias por capas, pianos, bordes y referencias visuales de asfalto.
- Eliminados árboles, tribunas y edificios decorativos del interior de los circuitos.
- Parrilla completa de 22 autos: dos pilotos por escudería, con nombres y números.
- Eliminada la radio y las intervenciones repetitivas del coach.
- Temporadas de 24 fechas en campeonato, modo piloto y modo dueño.

SISTEMAS IMPLEMENTADOS
- Vista superior 2D, cámara centrada en el auto, asfalto, pianos y áreas de escape.
- Autos con carrocería diferenciada, sombras, ruedas y detalles.
- Aceleración, frenado, inercia, agarre, pérdida de velocidad fuera de pista y daño.
- Colisiones entre autos, vueltas, cronometraje, clasificación y podio.
- Puntos, palmarés y guardado local del progreso.

ACLARACIONES
La vista superior es una proyección 2D dibujada en Canvas, no un motor 3D real.
El modo Piloto se juega conduciendo en pista. El modo Dueño simula los resultados
según el nivel del equipo y las mejoras; no es una carrera conducible.
Los datos guardados se mantienen en el navegador del mismo perfil.

ETAPA 1 — CIRCUITOS (ACTUALIZACIÓN)
- Calzada ampliada de 178 a 232 unidades en los 24 circuitos.
- Nuevas capas de perímetro, escapatoria, grava, pianos y borde de pista.
- Añadidos boxes y pit lane junto a la recta de salida, además de tribunas y postes de seguridad exteriores.
- Se mantuvo el área interior despejada: las estructuras se colocan fuera del trazado.
- Los trazados actuales son aproximaciones basadas en los puntos del proyecto original; la reproducción exacta de cada circuito requiere datos geométricos verificados y queda pendiente.


ETAPA 2 — FÍSICA Y CONDUCCIÓN (ACTUALIZACIÓN)
- Aceleración, resistencia al avance y velocidad máxima diferenciadas por categoría.
- Frenada con potencia específica y pérdida de eficacia cuando los frenos se recalientan.
- Dirección dependiente de la velocidad y simulación simplificada de transferencia de carga.
- Límite de agarre, deslizamiento, freno de mano y desgaste/temperatura de neumáticos.
- Temperatura de motor, consumo de combustible y penalización de rendimiento sin combustible.
- Daños y pérdida de rendimiento al salir de pista.
- Panel de carrera con combustible, desgaste/temperatura de neumáticos y temperaturas de motor/frenos.
NOTA: la física es una simulación 2D simplificada y jugable, no un modelo físico profesional validado con telemetría real.


ETAPA 3 — CATEGORÍAS Y COMPETENCIAS (v1.6)
- El modo Campeonato utiliza la categoría seleccionada antes de iniciar la temporada.
- Cada campeonato tiene 24 fechas y mantiene sus puntos durante toda la temporada.
- Tabla independiente de pilotos: cada piloto suma puntos según su posición final.
- Tabla de escuderías: los puntos de sus pilotos se acumulan para el título de equipos.
- Sistema de puntuación: 25, 18, 15, 12, 10, 8, 6, 4, 2 y 1 punto para los diez primeros.
- En cada resultado de campeonato se muestran las dos tablas actualizadas.
- Al completar las 24 fechas se anuncian el campeón de pilotos y el campeón de escuderías.
- Las cuatro categorías existentes (Formula RS, GT RS, Touring RS y Rally RS) se pueden elegir para su propio campeonato.

NOTA DE ALCANCE
El campeonato de esta versión se juega localmente en el navegador. El ranking no es todavía
online ni compartido entre dispositivos; eso corresponde a la futura etapa de multijugador
y servidor. Los puntos de campeonato se mantienen durante la sesión actual del campeonato.


ACTUALIZACIÓN v1.7 — ETAPA 4: GESTIÓN Y MODO CARRERA
- Se actualizó la identificación de versión a BUILD 1.7.
- El selector de escuderías del modo Dueño ahora permite elegir entre las cuatro categorías (Formula RS, GT RS, Touring RS y Rally RS).
- La selección de categoría filtra las escuderías disponibles y actualiza los pilotos de la escudería seleccionada.
- La temporada del modo Dueño usa la parrilla de escuderías de la categoría elegida.
- Se mantienen los sistemas de presupuesto, mejoras de departamentos, contratación de personal, patrocinadores, premios, contratos/atributos del piloto, calendario de 24 fechas, puntos e historial.
- Se conserva el progreso guardado en el navegador. Los datos antiguos del modo Dueño se migran de forma compatible; las carreras antiguas siguen en Formula RS.
- Se corrigió el orden de inicialización de la categoría al cargar el dashboard de gestión.
- Se mantienen las funciones anteriores, las cuatro categorías y las 44 escuderías.

ALCANCE
La v1.7 continúa siendo un juego local en navegador. No incluye todavía multijugador/ranking online (Etapas 6 y 7). La simulación del modo Dueño es estratégica y no una carrera conducible.
