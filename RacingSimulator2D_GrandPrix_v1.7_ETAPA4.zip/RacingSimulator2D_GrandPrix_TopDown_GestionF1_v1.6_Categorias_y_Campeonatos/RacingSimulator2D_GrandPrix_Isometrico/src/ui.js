export function showScreen(id) {
  document.querySelectorAll(".screen").forEach(el=>el.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");
}
export function formatTime(seconds) {
  const m=Math.floor(seconds/60), s=(seconds%60).toFixed(1).padStart(4,"0");
  return `${String(m).padStart(2,"0")}:${s}`;
}