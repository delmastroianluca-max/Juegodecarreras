import {drawTrack,track,nearestTrack,racingLine,trackLength,pointAtDistance} from "./track.js";
import {drawCar} from "./car.js";
import {updateCar} from "./physics.js";
import {createRivals,updateRivals} from "./ai.js";

export class Game{
 constructor(canvas,input,category,team,onHud,options={}){
  this.canvas=canvas;this.ctx=canvas.getContext("2d");this.input=input;this.category=category;this.team=team;this.onHud=onHud;
  this.laps=options.laps||3;this.rivalCount=options.rivalCount===undefined?8:options.rivalCount;
  this.onFinish=options.onFinish||(()=>{});this.driverName=options.driverName||"PILOTO RS";
  const start=pointAtDistance(0),next=pointAtDistance(18);
  this.player={x:start.x,y:start.y,angle:Math.atan2(next.y-start.y,next.x-start.x),speed:0,vx:0,vy:0,damage:0,boostTimer:0,pitTimer:0,tyreWear:0,tyreTemp:82,brakeTemp:90,engineTemp:92,fuel:category.fuelCapacity||100};
  this.rivals=createRivals(category,this.rivalCount,team.id);this.running=false;this.paused=false;this.finished=false;this.last=0;this.elapsed=0;this.penaltyTime=0;this.animation=0;
  this.lap=1;this.lastDistance=0;this.lapStart=0;this.lapTimes=[];this.bestLap=null;this.collisionCooldown=0;this.rank=1;this.playerProgress=0;
  this.loop=this.loop.bind(this);
 }
 start(){this.running=true;this.last=performance.now();this.animation=requestAnimationFrame(this.loop);}
 stop(){this.running=false;cancelAnimationFrame(this.animation);}
 setPaused(value){this.paused=value;if(!value&&this.running){this.last=performance.now();this.animation=requestAnimationFrame(this.loop);}}
 resolveCollisions(dt){
  if(this.collisionCooldown>0)this.collisionCooldown-=dt;
  const edge=track.roadWidth*.52,near=nearestTrack(this.player.x,this.player.y);
  if(near.distance>edge+12&&this.collisionCooldown<=0){this.player.damage=Math.min(100,this.player.damage+4);this.collisionCooldown=.55;}
  for(const rival of this.rivals){
   const dx=this.player.x-rival.x,dy=this.player.y-rival.y,d=Math.hypot(dx,dy);
   if(d<32&&d>0&&this.collisionCooldown<=0){const nx=dx/d,ny=dy/d,overlap=32-d;this.player.x+=nx*(overlap*.65+5);this.player.y+=ny*(overlap*.65+5);rival.x-=nx*overlap*.35;rival.y-=ny*overlap*.35;this.player.speed*=.72;this.player.vx*=.65;this.player.vy*=.65;this.player.damage=Math.min(100,this.player.damage+11);rival.progress-=9;this.collisionCooldown=1.2;}
  }
 }
 loop(now){
  if(!this.running||this.paused||this.finished)return;
  const dt=Math.min((now-this.last)/1000,.033);this.last=now;this.elapsed+=dt;
  updateCar(this.player,this.input,dt,this.category);updateRivals(this.rivals,dt);this.rivals.forEach(r=>{if(!r.finished&&r.progress>=this.laps*trackLength){r.finished=true;r.finishTime=this.elapsed-(r.progress-this.laps*trackLength)/Math.max(1,r.speed);r.progress=this.laps*trackLength;}});this.resolveCollisions(dt);
  const near=nearestTrack(this.player.x,this.player.y),distance=near.distanceAlong;
  if(this.lastDistance>trackLength*.82&&distance<trackLength*.18&&this.player.speed>28){
   const lapTime=this.elapsed-this.lapStart;this.lapTimes.push(lapTime);this.bestLap=this.bestLap===null?lapTime:Math.min(this.bestLap,lapTime);this.lap++;this.lapStart=this.elapsed;
  }
  this.lastDistance=distance;this.playerProgress=this.lap>this.laps?this.laps*trackLength:(this.lap-1)*trackLength+distance;
  this.rank=1+this.rivals.filter(r=>r.finished?r.finishTime<(this.elapsed+this.penaltyTime):r.progress>this.playerProgress).length;
  this.render();
  this.onHud({speed:Math.round(this.player.speed*1.65/2),fuel:Math.round(this.player.fuel/Math.max(1,this.category.fuelCapacity||100)*100),tyreWear:Math.round(this.player.tyreWear),tyreTemp:Math.round(this.player.tyreTemp),engineTemp:Math.round(this.player.engineTemp),brakeTemp:Math.round(this.player.brakeTemp),time:this.elapsed+this.penaltyTime,lap:Math.min(this.lap,this.laps),laps:this.laps,position:this.rank,total:this.rivalCount+1,damage:Math.round(this.player.damage),offroad:near.distance>track.roadWidth*.47,bestLap:this.bestLap});
  if(this.lap>this.laps){this.finish();return;}
  this.animation=requestAnimationFrame(this.loop);
 }
 finish(){
  this.finished=true;this.running=false;
  const entries=[{isPlayer:true,finished:true,name:this.driverName,team:this.team.name,color:this.team.color,progress:this.laps*trackLength,time:this.elapsed+this.penaltyTime,damage:Math.round(this.player.damage)},...this.rivals.map(r=>({isPlayer:false,finished:!!r.finished,name:r.name,team:r.team,color:r.color,progress:r.progress,time:r.finishTime??null,damage:r.damage||0}))].sort((a,b)=>{if(a.finished&&b.finished)return a.time-b.time;if(a.finished!==b.finished)return a.finished?-1:1;return b.progress-a.progress;});
  entries.forEach((e,i)=>e.position=i+1);
  const player=entries.find(e=>e.isPlayer);
  this.onFinish({entries,position:player.position,time:this.elapsed+this.penaltyTime,bestLap:this.bestLap,lapTimes:this.lapTimes,damage:Math.round(this.player.damage),laps:this.laps,trackName:track.name,playerName:this.driverName});
 }
 render(){
  const c=this.ctx,w=this.canvas.width,h=this.canvas.height;
  c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,w,h);
  // Cámara cenital: el auto permanece centrado y el circuito se desplaza debajo.
  const zoom=1.12;c.save();c.translate(w/2,h/2);c.scale(zoom,zoom);c.translate(-this.player.x,-this.player.y);
  drawTrack(c);
  [...this.rivals,this.player].sort((a,b)=>a.y-b.y).forEach(car=>drawCar(c,car,car===this.player?this.team.color:car.color,car===this.player,this.category.type));
  c.restore();
  c.fillStyle="rgba(7,15,22,.88)";c.fillRect(16,16,310,58);c.fillStyle="#d8e7e8";c.font="bold 14px sans-serif";c.fillText("RS / GRAND PRIX · VISTA SUPERIOR",30,39);c.fillStyle="#f0bd4c";c.font="12px sans-serif";c.fillText(track.name.toUpperCase(),30,59);
  c.fillStyle="rgba(7,15,22,.88)";c.fillRect(w-142,16,126,58);c.fillStyle="#fff";c.font="bold 15px sans-serif";c.fillText("LIVE · "+this.lap+"/"+this.laps,w-126,51);
 }
}
