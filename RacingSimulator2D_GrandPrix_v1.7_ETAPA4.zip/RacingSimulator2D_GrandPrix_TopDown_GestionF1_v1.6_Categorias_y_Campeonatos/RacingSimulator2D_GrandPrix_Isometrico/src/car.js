function bodyPath(ctx,type){
 ctx.beginPath();
 if(type==="formula"){
  ctx.moveTo(32,0);ctx.lineTo(21,-7);ctx.lineTo(11,-9);ctx.lineTo(6,-5);ctx.lineTo(-14,-5);ctx.lineTo(-22,-8);ctx.lineTo(-27,-7);ctx.lineTo(-27,7);ctx.lineTo(-22,8);ctx.lineTo(-14,5);ctx.lineTo(6,5);ctx.lineTo(11,9);ctx.lineTo(21,7);ctx.closePath();
 }else if(type==="rally"){
  ctx.roundRect(-24,-13,49,26,6);
 }else if(type==="touring"){
  ctx.moveTo(25,-7);ctx.lineTo(18,-13);ctx.lineTo(-16,-13);ctx.lineTo(-26,-8);ctx.lineTo(-28,7);ctx.lineTo(-19,13);ctx.lineTo(17,13);ctx.lineTo(26,7);ctx.closePath();
 }else{
  ctx.moveTo(27,-8);ctx.lineTo(18,-14);ctx.lineTo(-15,-13);ctx.lineTo(-25,-7);ctx.lineTo(-26,8);ctx.lineTo(-15,13);ctx.lineTo(17,12);ctx.lineTo(27,6);ctx.closePath();
 }
}
export function drawCar(ctx,car,color,isPlayer=false,type="formula"){
 ctx.save();ctx.translate(car.x,car.y);ctx.rotate(car.angle);
 // Ground shadow and visible lower side create body volume.
 ctx.fillStyle="rgba(0,0,0,.38)";ctx.beginPath();ctx.ellipse(3,9,34,19,0,0,Math.PI*2);ctx.fill();
 for(const x of [-17,15])for(const y of [-14,14]){ctx.fillStyle="#11161b";ctx.beginPath();ctx.roundRect(x-5,y-4,12,9,2);ctx.fill();ctx.fillStyle="#82919a";ctx.fillRect(x-2,y-3,6,7);ctx.fillStyle="#d9e1e4";ctx.fillRect(x-1,y-2,3,5);}
 bodyPath(ctx,type);ctx.save();ctx.translate(0,5);ctx.fillStyle="#111820";ctx.fill();ctx.restore();
 bodyPath(ctx,type);ctx.fillStyle=color;ctx.fill();ctx.strokeStyle="#101820";ctx.lineWidth=1.7;ctx.stroke();
 // upper highlight panel
 ctx.fillStyle="rgba(255,255,255,.20)";ctx.beginPath();ctx.moveTo(22,-5);ctx.lineTo(13,-10);ctx.lineTo(-13,-9);ctx.lineTo(-18,-5);ctx.lineTo(6,-3);ctx.closePath();ctx.fill();
 if(type==="formula"){
  ctx.fillStyle="#111820";ctx.fillRect(18,-16,15,32);ctx.fillStyle=color;ctx.fillRect(20,-14,13,5);ctx.fillRect(20,9,13,5);
  ctx.fillStyle="#1a242b";ctx.fillRect(-29,-15,9,30);ctx.fillStyle=color;ctx.fillRect(-31,-17,14,4);ctx.fillRect(-31,13,14,4);
  ctx.fillStyle="#172b3b";ctx.beginPath();ctx.ellipse(4,0,9,6,0,0,7);ctx.fill();
 }else{
  ctx.fillStyle="#111820";ctx.fillRect(-28,-15,10,3);ctx.fillRect(-28,12,10,3);
  ctx.fillStyle="#193447";ctx.beginPath();ctx.moveTo(-8,-10);ctx.lineTo(13,-9);ctx.lineTo(18,0);ctx.lineTo(13,9);ctx.lineTo(-8,10);ctx.lineTo(-14,0);ctx.closePath();ctx.fill();
  ctx.fillStyle="rgba(145,211,233,.72)";ctx.beginPath();ctx.moveTo(-7,-8);ctx.lineTo(11,-7);ctx.lineTo(15,0);ctx.lineTo(11,7);ctx.lineTo(-7,8);ctx.closePath();ctx.fill();
  if(type==="gt"){ctx.fillStyle="#151c23";ctx.fillRect(-25,-13,10,26);}
  if(type==="rally"){ctx.fillStyle="#fff";ctx.fillRect(-3,-12,4,24);ctx.fillStyle="#f0bd4c";ctx.fillRect(-12,-12,4,24);}
 }
 ctx.fillStyle=isPlayer?"#fff3c4":"rgba(255,255,255,.85)";ctx.fillRect(-13,-2,18,4);
 ctx.fillStyle="#fff1b0";ctx.fillRect(23,-6,4,4);ctx.fillRect(23,2,4,4);
 ctx.fillStyle="#da453c";ctx.fillRect(-27,-5,3,3);ctx.fillRect(-27,2,3,3);
 if(isPlayer){ctx.strokeStyle="#fff";ctx.lineWidth=1.4;ctx.strokeRect(-34,-19,68,38);}
 ctx.restore();
}
