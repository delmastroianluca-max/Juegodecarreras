export class Input {
  constructor() {
    this.keys = new Set();
    window.addEventListener("keydown", e => {
      const key = e.key.toLowerCase();
      if (["arrowup","arrowdown","arrowleft","arrowright"," "].includes(key)) e.preventDefault();
      this.keys.add(key);
    });
    window.addEventListener("keyup", e => this.keys.delete(e.key.toLowerCase()));
  }
  down(...keys) { return keys.some(key => this.keys.has(key)); }
}