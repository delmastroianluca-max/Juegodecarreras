export const categories = [
  { id:"formula", name:"FORMULA RS", description:"Monoplazas · máxima velocidad y precisión", type:"formula", topSpeed:212, acceleration:1.08, grip:1.12, turnRate:2.45, brakePower:285, cornering:2.8, fuelCapacity:105, fuelUse:.24, coastDrag:7 },
  { id:"touring", name:"TOURING RS", description:"Turismos · estabilidad y contacto rueda a rueda", type:"touring", topSpeed:150, acceleration:.92, grip:1.16, turnRate:2.28, brakePower:225, cornering:2.25, fuelCapacity:95, fuelUse:.19, coastDrag:8 },
  { id:"gt", name:"GT RS", description:"Gran turismo · potencia, carga y equilibrio", type:"gt", topSpeed:166, acceleration:1.0, grip:1.04, turnRate:2.16, brakePower:245, cornering:2.4, fuelCapacity:100, fuelUse:.21, coastDrag:7.5 },
  { id:"rally", name:"RALLY RS", description:"Rally · control y tracción en superficies mixtas", type:"rally", topSpeed:142, acceleration:.96, grip:.98, turnRate:2.5, brakePower:205, cornering:2.05, fuelCapacity:80, fuelUse:.2, coastDrag:8.5 }
];
