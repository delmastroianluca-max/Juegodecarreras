import {nearestTrack,track} from "./track.js";
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const approach=(value,target,amount)=>value+(target-value)*clamp(amount,0,1);

// Velocidad interna en unidades de pista/segundo. La interfaz aplica el factor
// de conversión visual definido por el proyecto (1 unidad/s = 1,65 km/h).
export function updateCar(car,input,dt,category){
 if(car.pitTimer>0){car.pitTimer=Math.max(0,car.pitTimer-dt);car.speed=0;car.vx=0;car.vy=0;return;}
 const throttle=input.down("w","arrowup"),brake=input.down("s","arrowdown"),left=input.down("a","arrowleft"),right=input.down("d","arrowright"),handbrake=input.down(" ");
 car.tyreWear=car.tyreWear??0;car.tyreTemp=car.tyreTemp??82;car.brakeTemp=car.brakeTemp??90;car.engineTemp=car.engineTemp??92;car.fuel=car.fuel??(category.fuelCapacity||100);car.loadTransfer=car.loadTransfer??0;car.slipAngle=car.slipAngle??0;
 const damage=car.damage||0,damageFactor=1-damage*.003;
 const maxSpeed=(category.topSpeed||180)*damageFactor*(car.boostTimer>0?1.08:1);
 if(car.boostTimer>0)car.boostTimer=Math.max(0,car.boostTimer-dt);
 const fuelFactor=car.fuel<=0?.72:1;
 const wearFactor=1-car.tyreWear*.0032;
 const tyreTempGrip=clamp(1-Math.abs(car.tyreTemp-92)*.0045,.72,1.04);
 const gripBase=(category.grip||1)*wearFactor*tyreTempGrip*(1-damage*.0015);
 const fuelUse=throttle?(category.fuelUse||.22)*(0.55+car.speed/Math.max(1,maxSpeed)*.8):.012;
 car.fuel=Math.max(0,car.fuel-fuelUse*dt);

 const accel=(category.acceleration||1)*92*fuelFactor*(1-damage*.0012);
 if(throttle&&car.fuel>0)car.speed+=accel*dt;
 else car.speed-=((category.coastDrag||7)+car.speed*.045)*dt;
 if(brake){const brakeForce=(category.brakePower||235)*clamp(1-car.brakeTemp/1250-(car.brakeFade||0),.58,1);car.speed-=brakeForce*dt;}
 car.speed=clamp(car.speed,0,maxSpeed);

 // Transferencia longitudinal de carga aproximada: al frenar carga el eje delantero;
 // al acelerar se desplaza hacia atrás. El freno de mano descarga el eje trasero.
 const longitudinal=throttle?-.16:brake?.34:0;
 car.loadTransfer=approach(car.loadTransfer,longitudinal,dt*3.8);
 const steer=(right?1:0)-(left?1:0),speedRatio=car.speed/Math.max(1,maxSpeed);
 const steeringAuthority=clamp(.28+speedRatio*.9,.28,1.08);
 const steeringRate=(category.turnRate||2.2)*steeringAuthority*(handbrake?1.42:1);
 const oldAngle=car.angle;
 car.angle+=steer*steeringRate*dt;
 const targetVx=Math.cos(car.angle)*car.speed,targetVy=Math.sin(car.angle)*car.speed;
 const lateralDemand=Math.abs(Math.atan2(Math.sin(car.angle-oldAngle),Math.cos(car.angle-oldAngle)))*car.speed/Math.max(.1,dt);
 const grip=clamp(gripBase*(handbrake?.58:1)*(1+car.loadTransfer*.22),.3,1.28);
 const lateralLimit=(category.cornering||2.4)*grip*115;
 const slip=clamp(lateralDemand/Math.max(1,lateralLimit),0,1.8);
 car.slipAngle=approach(car.slipAngle,slip,dt*5);
 const response=clamp(grip*dt*(handbrake?3.1:5.2),0,1);
 car.vx+=(targetVx-car.vx)*response;car.vy+=(targetVy-car.vy)*response;
 // Si se supera el agarre disponible, el coche desliza y pierde velocidad.
 if(slip>1){const loss=clamp((slip-1)*.9,0,.38);car.vx*=1-loss*dt*4;car.vy*=1-loss*dt*4;car.speed*=1-loss*dt*1.7;}
 car.x+=car.vx*dt;car.y+=car.vy*dt;

 const near=nearestTrack(car.x,car.y),edge=track.roadWidth*.47;
 if(near.distance>edge){const excess=near.distance-edge;car.speed*=Math.max(.76,1-2.6*dt);car.vx*=.86;car.vy*=.86;car.tyreWear=Math.min(100,car.tyreWear+dt*(.12+excess*.006));if(excess>12)car.damage=Math.min(100,damage+excess*.0018+dt*.65);if(near.distance>track.roadWidth*.92){const dx=near.point.x-car.x,dy=near.point.y-car.y,dist=Math.hypot(dx,dy)||1;car.vx+=dx/dist*22*dt;car.vy+=dy/dist*22*dt;}}

 const slipWear=Math.max(0,slip-.72);
 car.tyreWear=clamp(car.tyreWear+dt*(throttle?.018:.008)+slipWear*dt*.11,0,100);
 car.tyreTemp=approach(car.tyreTemp,78+speedRatio*24+slip*16,dt*(.16+speedRatio*.12));
 car.brakeTemp=approach(car.brakeTemp,brake?Math.min(850,car.brakeTemp+95):75+speedRatio*40,dt*(brake?.8:.12));
 car.engineTemp=approach(car.engineTemp,throttle?108+speedRatio*16:88,dt*(throttle?.12:.055));
 if(car.engineTemp>132)car.damage=Math.min(100,(car.damage||0)+dt*.12);
 if(car.brakeTemp>760)car.brakeFade=clamp((car.brakeTemp-760)/500,0,.35);else car.brakeFade=0;
 if(car.fuel<=0)car.engineTemp=Math.max(75,car.engineTemp-dt*2);
}
