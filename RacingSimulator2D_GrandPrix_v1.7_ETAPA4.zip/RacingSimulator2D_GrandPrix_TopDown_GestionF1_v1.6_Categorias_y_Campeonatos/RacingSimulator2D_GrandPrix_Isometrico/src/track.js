const presets = {
  monaco:{name:"Circuit de Monaco",country:"Mónaco",difficulty:"EXPERTO",theme:"city",roadWidth:232,points:[[180,180],[340,115],[520,135],[690,100],[850,190],[900,340],[810,445],[700,400],[625,300],[540,390],[430,540],[270,600],[125,520],[90,370],[130,260]]},
  spa:{name:"Circuit de Spa-Francorchamps",country:"Bélgica",difficulty:"EXPERTO",theme:"forest",roadWidth:232,points:[[145,220],[330,105],[550,125],[710,245],[660,410],[825,535],[1050,500],[1285,320],[1470,390],[1410,620],[1200,780],[950,700],[790,870],[540,810],[340,660],[140,565],[75,385]]},
  silverstone:{name:"Silverstone Circuit",country:"Reino Unido",difficulty:"AVANZADO",theme:"country",roadWidth:232,points:[[160,190],[360,105],[560,150],[745,95],[950,150],[1150,120],[1350,255],[1290,430],[1110,475],[930,395],[790,540],[970,690],[1200,670],[1410,540],[1510,710],[1320,900],[1080,930],[850,825],[620,900],[410,780],[225,845],[85,650],[125,420]]},
  suzuka:{name:"Suzuka International Racing Course",country:"Japón",difficulty:"EXPERTO",theme:"forest",roadWidth:232,points:[[135,250],[300,130],[500,155],[660,285],[820,190],[1030,135],[1235,260],[1190,425],[1010,495],[880,620],[1040,770],[1260,740],[1440,570],[1380,390],[1190,330],[1020,450],[810,520],[660,690],[450,785],[245,700],[90,530]]},
  bahrain:{name:"Bahrain International Circuit",country:"Baréin",difficulty:"INTERMEDIO",theme:"desert",roadWidth:232,points:[[135,170],[385,110],[640,150],[900,110],[1175,175],[1440,320],[1370,500],[1130,555],[930,435],[745,520],[870,730],[1140,805],[1400,700],[1320,920],[1030,970],[750,900],[510,955],[270,820],[85,635],[170,420]]},
  marina:{name:"Marina Bay Street Circuit",country:"Singapur",difficulty:"EXPERTO",theme:"night",roadWidth:232,points:[[170,150],[410,105],[655,155],[880,100],[1110,170],[1310,300],[1260,455],[1070,430],[930,555],[1080,700],[1320,640],[1480,790],[1290,930],[1030,870],[830,955],[625,815],[445,895],[250,770],[90,600],[155,405]]},
  interlagos:{name:"Autódromo José Carlos Pace",country:"Brasil",difficulty:"AVANZADO",theme:"hills",roadWidth:232,points:[[170,180],[395,105],[665,165],[900,120],[1090,260],[1020,435],[835,485],[690,390],[525,470],[635,645],[885,720],[1110,655],[1300,770],[1170,920],[900,900],[690,790],[455,850],[245,725],[90,515]]},
  redrock:{name:"Circuit of The Americas",country:"Estados Unidos",difficulty:"PRINCIPIANTE",theme:"desert",roadWidth:232,points:[[170,180],[450,120],[755,150],[1080,115],[1370,235],[1480,490],[1340,750],[1070,900],[740,880],[430,940],[155,765],[75,475]]},
  forest:{name:"Circuit Gilles-Villeneuve",country:"Canadá",difficulty:"INTERMEDIO",theme:"forest",roadWidth:232,points:[[155,180],[390,110],[580,195],[760,115],[990,175],[1180,310],[1090,450],[900,405],[770,570],[930,725],[1190,710],[1400,545],[1500,740],[1280,925],[1000,875],[790,970],[555,850],[355,915],[125,735],[70,455]]},
  coastal:{name:"Autódromo Internacional do Algarve",country:"Portugal",difficulty:"AVANZADO",theme:"coast",roadWidth:232,points:[[145,205],[375,110],[610,155],[840,105],[1040,180],[1200,330],[1120,475],[930,440],[785,570],[940,720],[1180,680],[1410,560],[1510,760],[1310,930],[1040,890],[815,980],[575,845],[355,920],[130,750],[75,485]]},
  industrial:{name:"Circuit Zandvoort",country:"Alemania",difficulty:"AVANZADO",theme:"industrial",roadWidth:232,points:[[170,150],[440,100],[680,150],[860,100],[1080,185],[1210,350],[1100,475],[915,430],[800,585],[960,725],[1190,710],[1390,570],[1485,760],[1280,930],[1030,860],[830,960],[600,830],[395,900],[150,735],[90,480]]},
  highland:{name:"Autodromo Nazionale Monza",country:"Italia",difficulty:"EXPERTO",theme:"hills",roadWidth:232,points:[[160,200],[345,105],[545,155],[705,285],[620,435],[775,560],[1010,505],[1170,335],[1400,390],[1490,590],[1320,760],[1110,685],[950,835],[720,935],[510,820],[325,910],[130,760],[75,520]]},

  imola:{name:"Autodromo Enzo e Dino Ferrari",country:"Italia",difficulty:"EXPERTO",theme:"hills",roadWidth:232,points:[[180,170],[400,110],[610,180],[760,320],[680,470],[850,570],[1060,520],[1240,360],[1430,420],[1390,640],[1200,800],[980,720],[790,900],[570,820],[380,940],[160,760],[80,510]]},
  catalunya:{name:"Circuit de Barcelona-Catalunya",country:"España",difficulty:"AVANZADO",theme:"coast",roadWidth:232,points:[[150,180],[390,110],[640,150],[900,110],[1180,180],[1430,320],[1380,520],[1190,620],[1010,540],[850,680],[1080,820],[1330,760],[1450,920],[1160,970],[900,870],[650,960],[400,850],[150,700],[75,440]]},
  hungaroring:{name:"Hungaroring",country:"Hungría",difficulty:"EXPERTO",theme:"forest",roadWidth:232,points:[[160,210],[370,120],[610,150],[800,260],[720,420],[900,500],[1120,430],[1310,280],[1480,390],[1410,610],[1210,740],[1000,650],[830,820],[600,900],[390,790],[180,850],[80,610],[90,390]]},
  redbullring:{name:"Red Bull Ring",country:"Austria",difficulty:"INTERMEDIO",theme:"hills",roadWidth:232,points:[[150,210],[390,110],[640,170],[880,120],[1110,250],[1330,190],[1480,380],[1350,590],[1130,650],[930,510],[720,620],[520,800],[300,730],[100,560]]},
  yasmarina:{name:"Yas Marina Circuit",country:"Emiratos Árabes Unidos",difficulty:"AVANZADO",theme:"night",roadWidth:232,points:[[160,180],[390,110],[650,150],[900,110],[1150,180],[1400,320],[1460,540],[1280,680],[1080,600],[930,760],[1120,900],[1390,850],[1480,1010],[1170,1040],[900,920],[650,990],[420,850],[180,700],[80,450]]},
  jeddah:{name:"Jeddah Corniche Circuit",country:"Arabia Saudita",difficulty:"EXPERTO",theme:"coast",roadWidth:232,points:[[170,120],[390,160],[610,100],[850,170],[1080,100],[1310,180],[1490,350],[1400,520],[1210,450],[1050,600],[1240,760],[1460,720],[1510,930],[1260,1010],[1030,900],[820,1010],[600,880],[390,960],[160,800],[80,570],[130,350]]},
  baku:{name:"Baku City Circuit",country:"Azerbaiyán",difficulty:"EXPERTO",theme:"city",roadWidth:232,points:[[140,180],[380,120],[620,160],[860,110],[1100,180],[1370,130],[1490,340],[1370,520],[1160,480],[980,650],[1190,820],[1440,760],[1490,960],[1210,1020],[960,900],[720,970],[500,820],[280,900],[90,720],[80,480]]},
  shanghai:{name:"Shanghai International Circuit",country:"China",difficulty:"AVANZADO",theme:"industrial",roadWidth:232,points:[[150,180],[380,100],[640,150],[860,300],[1110,180],[1370,260],[1480,480],[1300,650],[1080,570],[930,760],[1120,930],[1390,850],[1460,1030],[1150,1050],[900,900],[650,980],[420,820],[180,900],[80,650],[100,400]]},
  albertpark:{name:"Albert Park Grand Prix Circuit",country:"Australia",difficulty:"INTERMEDIO",theme:"coast",roadWidth:232,points:[[180,180],[400,110],[650,160],[850,100],[1100,180],[1370,130],[1490,340],[1380,540],[1180,470],[1010,630],[1170,800],[1410,760],[1480,950],[1190,1000],[950,870],[710,960],[480,830],[250,900],[90,700],[80,430]]},
  lusail:{name:"Lusail International Circuit",country:"Catar",difficulty:"AVANZADO",theme:"desert",roadWidth:232,points:[[170,180],[420,110],[670,150],[900,110],[1150,180],[1400,300],[1480,520],[1320,700],[1110,620],[930,790],[1130,940],[1390,880],[1480,1040],[1170,1060],[900,930],[650,1010],[420,850],[170,920],[80,680],[100,430]]},
  mexicocity:{name:"Autódromo Hermanos Rodríguez",country:"México",difficulty:"INTERMEDIO",theme:"city",roadWidth:232,points:[[150,180],[390,110],[640,160],[900,100],[1160,170],[1420,300],[1480,520],[1300,680],[1080,600],[900,760],[1080,900],[1350,850],[1480,1020],[1170,1040],[900,900],[650,970],[420,820],[180,900],[80,650],[100,410]]},
  vegas:{name:"Las Vegas Strip Circuit",country:"Estados Unidos",difficulty:"AVANZADO",theme:"night",roadWidth:232,points:[[130,160],[380,100],[650,160],[920,100],[1190,160],[1460,300],[1500,520],[1320,680],[1100,600],[920,760],[1120,900],[1400,850],[1500,1030],[1190,1050],[920,900],[660,980],[420,830],[170,900],[80,660],[80,420]]},

};
export const trackNames=Object.entries(presets).map(([id,t])=>({id,name:t.name,country:t.country,difficulty:t.difficulty}));
export let track={...presets.monaco,id:"monaco"};
export let racingLine=[];
export let trackLength=0;
function spline(points,steps=18){
 const out=[];
 for(let i=0;i<points.length;i++){
  const p0=points[(i-1+points.length)%points.length],p1=points[i],p2=points[(i+1)%points.length],p3=points[(i+2)%points.length];
  for(let j=0;j<steps;j++){
   const t=j/steps,t2=t*t,t3=t2*t;
   out.push({x:.5*(2*p1[0]+(-p0[0]+p2[0])*t+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*t2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*t3),y:.5*(2*p1[1]+(-p0[1]+p2[1])*t+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*t2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*t3)});
  }
 }
 return out;
}
function rebuild(){racingLine=spline(track.points);trackLength=0;for(let i=0;i<racingLine.length;i++){const a=racingLine[i],b=racingLine[(i+1)%racingLine.length];a.distance=trackLength;trackLength+=Math.hypot(b.x-a.x,b.y-a.y);} }
export function setTrack(id){track={...(presets[id]||presets.monaco),id};rebuild();return track;}
setTrack("monaco");
export function pointAtDistance(distance){let d=((distance%trackLength)+trackLength)%trackLength;if(d<1e-6){const a=racingLine[0],b=racingLine[1];return{x:a.x,y:a.y,angle:Math.atan2(b.y-a.y,b.x-a.x),index:0,distanceAlong:0};}let lo=0,hi=racingLine.length;while(lo<hi){const mid=(lo+hi)>>1;if(racingLine[mid].distance<d)lo=mid+1;else hi=mid;}const i=lo===racingLine.length?racingLine.length-1:Math.max(0,lo-1),j=(i+1)%racingLine.length,a=racingLine[i],b=racingLine[j],endDistance=j===0?trackLength:b.distance,seg=Math.max(1,endDistance-a.distance),t=(d-a.distance)/seg;return{x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,angle:Math.atan2(b.y-a.y,b.x-a.x),index:i,distanceAlong:d};}
export function nearestTrack(x,y){let best=null,dist=Infinity,index=0;for(let i=0;i<racingLine.length;i++){const p=racingLine[i],d=Math.hypot(x-p.x,y-p.y);if(d<dist){dist=d;best=p;index=i;}}return{point:best,distance:dist,index,distanceAlong:best?.distance||0};}
function stroke(ctx,width,color,dy=0){ctx.beginPath();racingLine.forEach((p,i)=>i?ctx.lineTo(p.x,p.y+dy):ctx.moveTo(p.x,p.y+dy));ctx.closePath();ctx.lineJoin="round";ctx.lineCap="round";ctx.lineWidth=width;ctx.strokeStyle=color;ctx.stroke();}
function pathStroke(ctx,points,width,color){ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.lineJoin="round";ctx.lineCap="round";ctx.lineWidth=width;ctx.strokeStyle=color;ctx.stroke();}
function offsetPoint(a,b,distance){const angle=Math.atan2(b.y-a.y,b.x-a.x);return{x:(a.x+b.x)/2-Math.sin(angle)*distance,y:(a.y+b.y)/2+Math.cos(angle)*distance,angle};}
function drawGrandstand(ctx,x,y,angle,length=150){ctx.save();ctx.translate(x,y);ctx.rotate(angle);ctx.fillStyle="#18232b";ctx.fillRect(-length/2-8,-25,length+16,50);ctx.fillStyle="#687780";ctx.fillRect(-length/2,-20,length,40);for(let row=0;row<4;row++){ctx.fillStyle=row%2?"#c8d0d0":"#9aa7a9";ctx.fillRect(-length/2+4,-17+row*9,length-8,5);}ctx.fillStyle="#d8e0df";ctx.fillRect(-length/2,-28,length,5);ctx.restore();}
function drawPitComplex(ctx){
 const a=racingLine[0],b=racingLine[Math.min(18,racingLine.length-1)],ang=Math.atan2(b.y-a.y,b.x-a.x);
 const mid=offsetPoint(a,b,track.roadWidth/2+45);ctx.save();ctx.translate(mid.x,mid.y);ctx.rotate(mid.angle);
 // Pit lane parallel to the start/finish straight, separated by a safety strip.
 ctx.fillStyle="#242d32";ctx.fillRect(-155,-track.roadWidth/2-53,310,track.roadWidth+106);
 ctx.fillStyle="#3a4247";ctx.fillRect(-155,-track.roadWidth/2-43,310,track.roadWidth+86);
 ctx.setLineDash([16,12]);ctx.strokeStyle="#f2f0e7";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-145,-track.roadWidth/2-8);ctx.lineTo(145,-track.roadWidth/2-8);ctx.stroke();ctx.setLineDash([]);
 // Pit garages and team bays stay outside the racing surface.
 const bayW=27,bayH=track.roadWidth+24;for(let i=0;i<10;i++){const x=-140+i*28;ctx.fillStyle=i%2?"#aeb9bb":"#d4d9d6";ctx.fillRect(x,-track.roadWidth/2-39,bayW-3,bayH);ctx.fillStyle="#25343b";ctx.fillRect(x+3,-track.roadWidth/2-31,bayW-9,18);ctx.fillStyle="#e4b84f";ctx.fillRect(x+4,track.roadWidth/2-5,bayW-10,4);}
 ctx.fillStyle="#17232b";ctx.fillRect(-160,-track.roadWidth/2-62,320,18);ctx.fillStyle="#f1f4ef";ctx.font="bold 12px sans-serif";ctx.textAlign="center";ctx.fillText("PIT LANE · TEAM GARAGES",0,-track.roadWidth/2-49);ctx.restore();
}
export function drawTrack(ctx){
 const ground=track.theme==="desert"?"#a28c51":track.theme==="night"?"#33454d":track.theme==="coast"?"#5b865d":"#47794c";
 ctx.fillStyle=ground;ctx.fillRect(-3000,-3000,6000,6000);
 // Broad terrain texture, deliberately kept subtle so it never competes with the racing line.
 for(let y=-80;y<1200;y+=52)for(let x=-80;x<1650;x+=58){ctx.fillStyle=((x/58|0)+(y/52|0))%2?"#ffffff08":"#092d1a10";ctx.beginPath();ctx.ellipse(x,y,15,5,-.3,0,7);ctx.fill();}
 if(track.theme==="coast"){ctx.fillStyle="#267e9d";ctx.beginPath();ctx.ellipse(1320,145,270,155,-.2,0,7);ctx.fill();ctx.strokeStyle="#8ed0d9";ctx.lineWidth=8;ctx.stroke();}
 if(track.theme==="desert"){for(let i=0;i<7;i++){ctx.strokeStyle="#c8ab6b44";ctx.lineWidth=10;ctx.beginPath();ctx.arc(180+i*210,820-(i%3)*120,95,0,Math.PI*1.35);ctx.stroke();}}
 // Circuit perimeter, gravel runoff and layered kerbs.
 stroke(ctx,track.roadWidth+150,"#263238",0);stroke(ctx,track.roadWidth+126,"#b8b6a9",0);stroke(ctx,track.roadWidth+102,"#c7b58a",0);stroke(ctx,track.roadWidth+82,"#8d8064",0);
 stroke(ctx,track.roadWidth+58,"#f0eee5",0);stroke(ctx,track.roadWidth+42,"#c43c3d",0);stroke(ctx,track.roadWidth+29,"#f0eee5",0);stroke(ctx,track.roadWidth,"#30383e",0);stroke(ctx,track.roadWidth-14,"#ffffff0b",0);
 // Asphalt edge and broken center reference line.
 ctx.setLineDash([30,34]);stroke(ctx,3,"#ffffff55");ctx.setLineDash([]);
 for(let i=0;i<racingLine.length;i+=3){const a=racingLine[i],b=racingLine[(i+1)%racingLine.length],ang=Math.atan2(b.y-a.y,b.x-a.x);for(const side of [-1,1]){const x=a.x-Math.sin(ang)*side*(track.roadWidth/2+9),y=a.y+Math.cos(ang)*side*(track.roadWidth/2+9);ctx.save();ctx.translate(x,y);ctx.rotate(ang);ctx.fillStyle=(i%6<3)?"#f4eee0":"#d8443e";ctx.fillRect(-9,-10,18,20);ctx.restore();}}
 // Start/finish line.
 const p=racingLine[0],q=racingLine[4],a=Math.atan2(q.y-p.y,q.x-p.x);ctx.save();ctx.translate(p.x,p.y);ctx.rotate(a);for(let i=0;i<24;i++){ctx.fillStyle=i%2?"#15191d":"#f5f4e9";ctx.fillRect(-10,-track.roadWidth/2+i*track.roadWidth/24,20,track.roadWidth/24);}ctx.restore();
 // Trackside structures: placed along the outside of the opening straight, never in the infield.
 const standA=offsetPoint(racingLine[3],racingLine[20],track.roadWidth/2+145);drawGrandstand(ctx,standA.x,standA.y,standA.angle,190);
 const standB=offsetPoint(racingLine[8],racingLine[25],track.roadWidth/2+155);drawGrandstand(ctx,standB.x,standB.y,standB.angle,160);
 drawPitComplex(ctx);
 // Safety fencing follows the outer edge as short dark posts.
 for(let i=0;i<racingLine.length;i+=9){const a=racingLine[i],b=racingLine[(i+1)%racingLine.length],ang=Math.atan2(b.y-a.y,b.x-a.x);for(const side of [-1,1]){const x=a.x-Math.sin(ang)*side*(track.roadWidth/2+65),y=a.y+Math.cos(ang)*side*(track.roadWidth/2+65);ctx.save();ctx.translate(x,y);ctx.rotate(ang);ctx.fillStyle="#17232b";ctx.fillRect(-3,-5,6,10);ctx.restore();}}
}
